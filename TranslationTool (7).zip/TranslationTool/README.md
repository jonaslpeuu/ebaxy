
# eBay Beschreibungsgenerator

## Ausführungsanleitung

### In Replit
1. Klicken Sie einfach auf den "Run"-Button oben im Replit-Interface.
2. Die Anwendung wird automatisch gestartet und ist unter der angezeigten URL verfügbar.

### In lokalen Entwicklungsumgebungen (z.B. Visual Studio Code)
1. Installieren Sie Node.js (Version 16 oder höher) und npm auf Ihrem Computer.
2. Öffnen Sie ein Terminal im Projektverzeichnis.
3. Führen Sie `npm install` aus, um alle Abhängigkeiten zu installieren.
4. Starten Sie die Anwendung mit `npm run dev`.
5. Die Anwendung ist dann unter http://localhost:3000 verfügbar.
6. **WICHTIG**: Öffnen Sie die Anwendung NICHT mit Live Server oder durch direktes Öffnen der HTML-Dateien!

## Fehlerbehebung

### NPM Install schlägt fehl
Wenn `npm install` einen Fehler ausgibt, versuchen Sie:
1. Löschen Sie den `node_modules` Ordner und die `package-lock.json` Datei.
2. Führen Sie `npm cache clean --force` aus.
3. Führen Sie erneut `npm install` aus.

### Weißer Bildschirm oder keine Anzeige
1. Überprüfen Sie, ob der Server läuft (Terminal sollte "serving on port 3000" anzeigen).
2. Verwenden Sie **NICHT** Live Server oder ähnliche Add-ons – diese funktionieren nicht mit Full-Stack-Anwendungen.
3. Öffnen Sie http://localhost:3000 direkt im Browser.

## Wichtige Hinweise
- Die Anwendung verwendet einen Full-Stack-Ansatz mit React im Frontend und Express im Backend.
- Stellen Sie sicher, dass Sie die Anwendung über den korrekten Befehl starten (nicht einzelne Dateien öffnen).
- Das Frontend wird über Vite gebundelt und vom Backend ausgeliefert.
- HuggingFace API: Falls Sie die KI-Funktionen nutzen möchten, benötigen Sie einen API-Token von HuggingFace.
