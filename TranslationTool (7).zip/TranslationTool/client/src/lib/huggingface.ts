import { HfInference } from "@huggingface/inference";

// Prüfe ob der Token verfügbar ist
const API_TOKEN = import.meta.env.VITE_HUGGINGFACE_API_TOKEN;
if (!API_TOKEN) {
  console.warn('Kein HuggingFace API Token gefunden - Verwende Offline-Modus');
}

const hf = API_TOKEN ? new HfInference(API_TOKEN) : null;

export async function generateDescription(
  title: string,
  condition: string
): Promise<string> {
  // Wenn kein Token verfügbar ist, wirf einen spezifischen Fehler
  if (!hf) {
    throw new Error("offline_mode_required");
  }

  try {
    const prompt = `Erstelle eine professionelle, verkaufsfördernde Beschreibung für eine eBay-Kleinanzeige.
Produkt: "${title}"
Zustand: ${condition}

Wichtige Vorgaben:
- Maximal 3 Sätze
- Sachlich und professionell
- Zustand des Artikels erwähnen
- Positiv formulieren
- Keine spezifischen Preise nennen
- Keine Erfindungen oder Spekulationen`;

    const response = await hf.textGeneration({
      model: "mistralai/Mistral-7B-Instruct-v0.1",
      inputs: prompt,
      parameters: {
        max_new_tokens: 150,
        temperature: 0.7,
        top_k: 50,
        top_p: 0.9,
        do_sample: true
      }
    });

    const description = response.generated_text.trim();
    if (!description) {
      throw new Error("Keine Beschreibung generiert");
    }

    return description;
  } catch (error: any) {
    console.error('Hugging Face API Error:', error);

    if (error.message.includes("Invalid credentials") || 
        error.message.includes("Unauthorized") ||
        error.message.includes("401")) {
      throw new Error("offline_mode_required");
    }

    throw new Error("Bei der KI-Generierung ist ein Fehler aufgetreten. Bitte verwenden Sie den Offline-Modus.");
  }
}