import OpenAI from "openai";

export async function generateGrokDescription(
  title: string,
  condition: string,
  apiKey: string
): Promise<string> {
  const openai = new OpenAI({ 
    baseURL: "https://api.x.ai/v1",
    apiKey: apiKey
  });

  try {
    const prompt = `Erstelle eine professionelle, verkaufsfördernde Beschreibung für eine eBay-Kleinanzeige.
Produkt: "${title}"
Zustand: ${condition}

Wichtige Vorgaben:
- Maximal 3 Sätze
- Sachlich und professionell
- Zustand des Artikels erwähnen
- Positiv formulieren
- Keine spezifischen Preise nennen
- Keine Erfindungen oder Spekulationen`;

    const response = await openai.chat.completions.create({
      model: "grok-2-1212",
      messages: [
        {
          role: "system",
          content: "Du bist ein erfahrener Verkäufer, der professionelle eBay-Artikelbeschreibungen erstellt."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      temperature: 0.7,
      max_tokens: 150
    });

    const message = response.choices[0]?.message?.content || "Es konnte keine Beschreibung generiert werden.";
    return message.trim();
  } catch (error: any) {
    // Spezifische API-Fehlermeldungen abfangen
    if (error.response?.status === 401) {
      throw new Error("invalid_api_key");
    } else if (error.response?.status === 429) {
      throw new Error("insufficient_quota");
    }

    throw new Error(error.message || "Fehler bei der Grok API-Anfrage");
  }
}