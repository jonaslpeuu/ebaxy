import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { generateDescription } from "@/lib/huggingface";
import { Loader2 } from "lucide-react";
import { ThemeToggle } from "@/components/theme-toggle";

const descriptionTemplates = {
  "neu": [
    "Zum Verkauf steht ein nagelneues ARTIKEL in ungeöffneter Originalverpackung. Alle Zubehörteile sind vorhanden und unbenutzt. Eine tolle Gelegenheit für Sammler und Qualitätsbewusste.",
    "Biete hier ein brandneues ARTIKEL an, direkt aus dem Fachhandel. Die Originalverpackung ist ungeöffnet, alle Siegel sind intakt. Ein Neukauf zum attraktiven Preis.",
    "Verkaufe ein absolut neuwertiges ARTIKEL mit voller Garantie. Unbenutzt und originalverpackt mit allem Zubehör. Ideal für alle, die Wert auf fabrikneue Ware legen.",
    "Nagelneu und unbenutzt: ARTIKEL mit kompletter Originalausstattung. Die Verpackung wurde nie geöffnet, alle Schutzfolien sind noch vorhanden. Eine perfekte Geschenkidee.",
    "Fabrikneues ARTIKEL zu verkaufen. Noch original eingeschweißt mit allen Dokumenten und Zubehörteilen. Ein Qualitätsprodukt zum fairen Preis."
  ],
  "sehr-gut": [
    "Verkaufe ein ARTIKEL in hervorragendem Zustand. Kaum genutzt und sehr gepflegt, praktisch wie neu. Technisch und optisch in einwandfreiem Zustand.",
    "Zum Verkauf steht ein ARTIKEL in Top-Zustand. Das Gerät wurde nur wenige Male benutzt und immer sorgsam behandelt. Keine Gebrauchsspuren erkennbar.",
    "Biete ein ARTIKEL in exzellentem Zustand. Wurde stets mit größter Sorgfalt behandelt und sieht aus wie neu. Alle Funktionen arbeiten einwandfrei.",
    "Fast neuwertig: ARTIKEL in bestem Zustand. Minimale Nutzung, keine sichtbaren Gebrauchsspuren. Technisch und optisch wie am ersten Tag.",
    "Premium-Zustand: ARTIKEL in herausragender Verfassung. Wurde kaum genutzt und immer in der Original-Schutzhülle aufbewahrt. Ein echtes Schmuckstück."
  ],
  "gut": [
    "Gepflegtes ARTIKEL in gutem Zustand zu verkaufen. Normale Gebrauchsspuren, technisch einwandfrei und voll funktionsfähig. Ein zuverlässiger Begleiter.",
    "Biete ein gut erhaltenes ARTIKEL an. Leichte Gebrauchsspuren, aber technisch top in Schuss. Alle Funktionen arbeiten wie sie sollen.",
    "Zum Verkauf steht ein ARTIKEL in gutem Gebrauchszustand. Die üblichen Nutzungsspuren, aber gepflegt und technisch ohne Mängel.",
    "ARTIKEL in solider Verfassung abzugeben. Wurde regelmäßig genutzt, aber gut gepflegt. Weist normale Gebrauchsspuren auf, funktioniert aber tadellos.",
    "Guter Zustand: ARTIKEL mit leichten Gebrauchsspuren. Technisch einwandfrei und regelmäßig gewartet. Ein verlässliches Produkt zum fairen Preis."
  ],
  "gebraucht": [
    "Gebrauchtes ARTIKEL in funktionsfähigem Zustand. Deutliche Nutzungsspuren, aber technisch zuverlässig. Ideal für preisbewusste Käufer.",
    "ARTIKEL mit sichtbaren Gebrauchsspuren zu verkaufen. Technisch voll funktionsfähig, optisch mit den üblichen Abnutzungserscheinungen. Ein ehrliches Produkt.",
    "Biete gebrauchtes ARTIKEL an. Die Spuren der Nutzung sind erkennbar, alle Funktionen arbeiten aber einwandfrei. Perfekt für den praktischen Einsatz.",
    "Zum Verkauf steht ein ARTIKEL mit deutlichen Gebrauchsspuren. Technisch in Ordnung und voll funktionsfähig. Ein robustes Produkt für den täglichen Gebrauch.",
    "Gebrauchter Zustand: ARTIKEL mit normalen Altersspuren. Wurde viel genutzt, ist aber technisch zuverlässig. Ein preiswerter Einstieg."
  ],
  "defekt": [
    "Verkaufe defektes ARTIKEL für Bastler oder zur Ersatzteilgewinnung. Das Gerät weist folgende Mängel auf: [BESCHREIBEN]. Ideal für technisch Versierte.",
    "ARTIKEL mit Defekt abzugeben. Geeignet für Bastler oder als Ersatzteillager. Das Gerät funktioniert nicht mehr richtig, kann aber repariert werden.",
    "Defektes ARTIKEL für Tüftler und Bastler. Die Hauptfunktionen sind eingeschränkt, viele Teile aber noch brauchbar. Perfekt zum Ausschlachten.",
    "Zum Verkauf steht ein ARTIKEL mit technischen Problemen. Nur für Bastler geeignet, da nicht mehr voll funktionsfähig. Gute Basis für ein Reparaturprojekt.",
    "Bastlerware: ARTIKEL mit erheblichen Mängeln. Nicht funktionsfähig, aber ideal als Ersatzteilspender oder für experimentierfreudige Tüftler."
  ],
  "sammler": [
    "Seltenes ARTIKEL für Sammler und Liebhaber. Ein echtes Sammlerstück in authentischem Zustand. Mit original Dokumentation und Zubehör.",
    "Zum Verkauf steht ein ARTIKEL für echte Sammler. Ein besonderes Exemplar mit interessanter Geschichte. Ideal für Ihre Kollektion.",
    "Biete ein ARTIKEL für Sammler an. Ein zeitgeschichtliches Dokument in originalgetreuem Zustand. Eine Bereicherung für jede Sammlung.",
    "Sammlerstück: ARTIKEL in historischem Zustand. Mit allen originalen Unterlagen und der typischen Patina. Ein Stück Zeitgeschichte.",
    "Für Liebhaber: ARTIKEL mit Sammlerwert. In authentischer Erhaltung mit allen Originalunterlagen. Ein Must-have für Enthusiasten."
  ],
  "vintage": [
    "Klassisches ARTIKEL im Vintage-Stil. Ein Zeitzeuge mit der schönen Patina vergangener Tage. Perfekt für Liebhaber des besonderen Designs.",
    "Vintage ARTIKEL zu verkaufen. Ein Klassiker mit Geschichte und dem unverwechselbaren Charme der Epoche. Ideal für Stilbewusste.",
    "Zum Verkauf steht ein ARTIKEL im Retro-Look. Ein authentisches Stück Zeitgeschichte mit wunderschöner Patina. Ein echtes Statement.",
    "Vintage-Schatz: ARTIKEL mit Geschichte. Die charakteristische Patina erzählt von vergangenen Zeiten. Ein Schmuckstück für Liebhaber.",
    "Retro-Style: ARTIKEL mit Charakter. Ein zeitloses Design-Objekt mit der unverwechselbaren Ausstrahlung seiner Epoche. Für wahre Kenner."
  ]
} as const;

const conditionLabels = {
  "neu": "neu/unbenutzt",
  "sehr-gut": "sehr gut erhalten",
  "gut": "gut erhalten",
  "gebraucht": "gebraucht mit Gebrauchsspuren",
  "defekt": "defekt/für Bastler",
  "sammler": "Sammlerstück/Rarität",
  "vintage": "Vintage/Retro"
} as const;

type Condition = keyof typeof conditionLabels;

export default function Home() {
  const [title, setTitle] = useState('');
  const [condition, setCondition] = useState<Condition>('sehr-gut');
  const [description, setDescription] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [copySuccess, setCopySuccess] = useState(false);

  const generateOfflineDescription = () => {
    if (!title) {
      setError('Bitte gib einen Anzeigentitel ein!');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const templates = descriptionTemplates[condition];
      const randomIndex = Math.floor(Math.random() * templates.length);
      const generatedDescription = templates[randomIndex].replace('ARTIKEL', title);
      setDescription(generatedDescription);
    } catch (error) {
      setError('Fehler beim Generieren der Beschreibung');
    } finally {
      setLoading(false);
    }
  };

  const generateAIDescription = async () => {
    if (!title) {
      setError('Bitte gib einen Anzeigentitel ein!');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const readableCondition = conditionLabels[condition];
      const generatedDescription = await generateDescription(title, readableCondition);
      setDescription(generatedDescription);
    } catch (error: any) {
      console.error('API-Fehler:', error);
      if (error.message === "offline_mode_required") {
        generateOfflineDescription();
      } else {
        setError(error.message);
      }
    } finally {
      setLoading(false);
    }
  };

  const copyText = async () => {
    const legalText = '❗️Privater Verkauf gemäß § 447 BGB – keine Garantie oder Rücknahme. Keine Rückgabe ❗️';
    const fullText = `${description}\n\n${legalText}`;

    try {
      await navigator.clipboard.writeText(fullText);
      setCopySuccess(true);
      setTimeout(() => setCopySuccess(false), 3000);
    } catch (err) {
      setError('Fehler beim Kopieren. Bitte kopiere den Text manuell.');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800 py-12 px-4 sm:px-6 lg:px-8">
      <ThemeToggle />
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="max-w-4xl mx-auto"
      >
        <div className="text-center mb-12">
          <motion.h1
            className="text-5xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-orange-600 to-blue-600"
            initial={{ scale: 0.9 }}
            animate={{ scale: 1 }}
            transition={{ duration: 0.5 }}
          >
            eBay Beschreibungsgenerator
          </motion.h1>
          <motion.p
            className="text-xl text-gray-600 dark:text-gray-300"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            Professionelle Beschreibungen für deine eBay-Anzeigen mit KI
          </motion.p>
        </div>

        <motion.div
          className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3 }}
        >
          <div className="space-y-6">
            <div>
              <label className="block text-lg font-semibold text-gray-700 dark:text-gray-200 mb-2">
                eBay Anzeigentitel
              </label>
              <input
                type="text"
                placeholder="z.B. Samsung Galaxy S21 128GB Schwarz"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full p-3 border-2 border-gray-200 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-gray-100"
                onKeyPress={(e) => {
                  if (e.key === 'Enter') {
                    generateAIDescription();
                  }
                }}
              />
            </div>

            <div>
              <label className="block text-lg font-semibold text-gray-700 dark:text-gray-200 mb-2">
                Zustand des Artikels
              </label>
              <select
                value={condition}
                onChange={(e) => setCondition(e.target.value as Condition)}
                className="w-full p-3 border-2 border-gray-200 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-gray-100"
              >
                <option value="neu">Neu / Unbenutzt</option>
                <option value="sehr-gut">Sehr gut erhalten</option>
                <option value="gut">Gut erhalten</option>
                <option value="gebraucht">Gebraucht mit Gebrauchsspuren</option>
                <option value="defekt">Defekt / Für Bastler</option>
                <option value="sammler">Sammlerstück/Rarität</option>
                <option value="vintage">Vintage/Retro</option>
              </select>
            </div>

            <AnimatePresence>
              {error && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="p-4 bg-red-50 dark:bg-red-800 border-l-4 border-red-500 dark:border-red-600 rounded-lg"
                >
                  <p className="text-red-700 dark:text-red-200">{error}</p>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="flex gap-4">
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={generateAIDescription}
                disabled={loading}
                className="flex-1 py-3 px-6 bg-gradient-to-r from-orange-600 to-orange-500 text-white rounded-lg font-semibold shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? (
                  <span className="flex items-center justify-center">
                    <Loader2 className="animate-spin mr-2" />
                    Generiere Beschreibung...
                  </span>
                ) : (
                  'KI-Beschreibung erstellen'
                )}
              </motion.button>

              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={generateOfflineDescription}
                disabled={loading}
                className="flex-1 py-3 px-6 bg-gradient-to-r from-gray-700 to-gray-600 text-white rounded-lg font-semibold shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Vorlage verwenden
              </motion.button>
            </div>

            <AnimatePresence>
              {description && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="mt-8 p-6 bg-gray-50 dark:bg-gray-700 rounded-xl border border-gray-200 dark:border-gray-600"
                >
                  <h3 className="text-xl font-semibold mb-4 text-gray-800 dark:text-gray-100">Deine fertige Beschreibung:</h3>
                  <p className="text-gray-700 dark:text-gray-200 mb-6 whitespace-pre-line">{description}</p>
                  <div className="p-4 bg-orange-50 dark:bg-orange-800 rounded-lg border-l-4 border-orange-500 dark:border-orange-600">
                    <p className="text-orange-700 dark:text-orange-200 font-medium">
                      ❗️Privater Verkauf gemäß § 447 BGB – keine Garantie oder Rücknahme. Keine Rückgabe ❗️
                    </p>
                  </div>

                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={copyText}
                    className="mt-6 w-full py-3 bg-blue-600 text-white rounded-lg font-semibold shadow-lg hover:bg-blue-700"
                  >
                    Text kopieren
                  </motion.button>

                  <AnimatePresence>
                    {copySuccess && (
                      <motion.p
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="mt-4 text-center text-green-600 dark:text-green-400 font-medium"
                      >
                        ✅ Text wurde in die Zwischenablage kopiert!
                      </motion.p>
                    )}
                  </AnimatePresence>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </motion.div>

        <motion.footer
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="mt-12 text-center text-gray-500 dark:text-gray-400 text-sm"
        >
          <p>
            Diese Seite generiert Beschreibungen für eBay-Anzeigen mit Hilfe von künstlicher Intelligenz.
            <br />
            Die Nutzung ist komplett kostenlos und erfordert keine Anmeldung.
          </p>
        </motion.footer>
      </motion.div>
    </div>
  );
}