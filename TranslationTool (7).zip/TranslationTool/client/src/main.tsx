
import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import "./index.css";

// Mit besserer Fehlerbehandlung
document.addEventListener("DOMContentLoaded", () => {
  const rootElement = document.getElementById("root");

  if (!rootElement) {
    console.error("Root element nicht gefunden! Überprüfe die HTML-Datei.");
    // Fallback: Erstelle ein Root-Element wenn es nicht existiert
    const fallbackRoot = document.createElement("div");
    fallbackRoot.id = "root";
    document.body.appendChild(fallbackRoot);
    
    ReactDOM.createRoot(fallbackRoot).render(
      <React.StrictMode>
        <App />
      </React.StrictMode>
    );
  } else {
    ReactDOM.createRoot(rootElement).render(
      <React.StrictMode>
        <App />
      </React.StrictMode>
    );
  }
});
