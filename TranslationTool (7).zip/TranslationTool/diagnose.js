
/**
 * Diagnose-Script zur Identifikation von häufigen Problemen
 * Führen Sie dieses Script mit "node diagnose.js" aus
 */

const fs = require('fs');
const { execSync } = require('child_process');
const http = require('http');

console.log('=== eBay Beschreibungsgenerator Diagnose ===');
console.log('Überprüfe Systemumgebung...');

// Überprüfe Node.js-Version
try {
  const nodeVersion = execSync('node -v').toString().trim();
  console.log(`✅ Node.js-Version: ${nodeVersion}`);
} catch (err) {
  console.error('❌ Node.js konnte nicht erkannt werden. Ist Node.js installiert?');
  process.exit(1);
}

// Überprüfe NPM-Version
try {
  const npmVersion = execSync('npm -v').toString().trim();
  console.log(`✅ NPM-Version: ${npmVersion}`);
} catch (err) {
  console.error('❌ NPM konnte nicht erkannt werden. Ist NPM installiert?');
}

// Überprüfe Projektstruktur
console.log('\nÜberprüfe Projektstruktur...');
const criticalFiles = [
  'package.json',
  'server/index.ts',
  'client/index.html',
  'vite.config.ts'
];

let missingFiles = false;
criticalFiles.forEach(file => {
  if (fs.existsSync(file)) {
    console.log(`✅ Datei gefunden: ${file}`);
  } else {
    console.log(`❌ Datei fehlt: ${file}`);
    missingFiles = true;
  }
});

if (missingFiles) {
  console.log('\n⚠️ Es fehlen wichtige Projektdateien. Stellen Sie sicher, dass Sie das komplette Projekt heruntergeladen haben.');
}

// Überprüfe node_modules
if (fs.existsSync('node_modules')) {
  console.log('✅ node_modules Ordner gefunden');
} else {
  console.log('❌ node_modules Ordner fehlt. Führen Sie "npm install" aus.');
}

// Überprüfe Port 3000
console.log('\nÜberprüfe Port 3000...');
try {
  const server = http.createServer();
  server.listen(3000, () => {
    console.log('✅ Port 3000 ist verfügbar');
    server.close();
    
    console.log('\n=== Diagnose abgeschlossen ===');
    console.log('Wenn alle Checks erfolgreich waren, sollte die Anwendung starten können.');
    console.log('Führen Sie "npm run dev" aus und öffnen Sie http://localhost:3000 im Browser.');
    console.log('\nWenn Probleme auftreten, beachten Sie die Anweisungen in ANLEITUNG.md');
  });
  
  server.on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
      console.log('❌ Port 3000 wird bereits verwendet. Ein anderer Prozess blockiert diesen Port.');
      console.log('   Beenden Sie alle anderen Server oder ändern Sie den Port in der Konfiguration.');
    } else {
      console.log(`❌ Fehler bei der Überprüfung von Port 3000: ${err.message}`);
    }
    process.exit(1);
  });
} catch (err) {
  console.log(`❌ Fehler bei der Überprüfung von Port 3000: ${err.message}`);
}
