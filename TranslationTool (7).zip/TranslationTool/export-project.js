
const fs = require('fs');
const path = require('path');
const archiver = require('archiver');

// Installiere archiver, falls nicht vorhanden
if (!fs.existsSync(path.join(process.cwd(), 'node_modules', 'archiver'))) {
  console.log('Installiere archiver...');
  require('child_process').execSync('npm install archiver --no-save');
}

// Erstelle Ausgabeverzeichnis, falls nicht vorhanden
const outputDir = path.join(process.cwd(), 'export');
if (!fs.existsSync(outputDir)) {
  fs.mkdirSync(outputDir);
}

// Erstelle ZIP-Datei
const output = fs.createWriteStream(path.join(outputDir, 'project.zip'));
const archive = archiver('zip', {
  zlib: { level: 9 } // Maximale Kompression
});

// Fehlerbehandlung
output.on('close', () => {
  console.log(`ZIP-Datei erstellt: ${archive.pointer()} Bytes`);
  console.log('Die Datei wurde unter /export/project.zip gespeichert.');
  console.log('Sie können sie im Datei-Explorer finden und herunterladen.');
});

archive.on('error', (err) => {
  throw err;
});

// Pipe Archiv-Daten an Output-Stream
archive.pipe(output);

// Ignoriere diese Verzeichnisse und Dateien
const ignorePatterns = [
  'node_modules',
  '.git',
  'dist',
  'export',
  '.DS_Store',
  '*.tar.gz'
];

// Funktion zum Überprüfen, ob ein Pfad ignoriert werden soll
function shouldIgnore(filePath) {
  return ignorePatterns.some(pattern => {
    if (pattern.includes('*')) {
      const regexPattern = pattern.replace(/\*/g, '.*');
      return new RegExp(regexPattern).test(filePath);
    }
    return filePath.includes(pattern);
  });
}

// Funktion zum rekursiven Hinzufügen von Dateien
function addDirectoryToArchive(dirPath, archivePath = '') {
  const files = fs.readdirSync(dirPath);
  
  files.forEach(file => {
    const filePath = path.join(dirPath, file);
    const stats = fs.statSync(filePath);
    const relativePath = path.join(archivePath, file);
    
    if (shouldIgnore(filePath)) {
      return;
    }
    
    if (stats.isDirectory()) {
      addDirectoryToArchive(filePath, relativePath);
    } else {
      archive.file(filePath, { name: relativePath });
    }
  });
}

// Füge alle Dateien zum Archiv hinzu
addDirectoryToArchive(process.cwd());

// Schließe das Archiv
archive.finalize();
