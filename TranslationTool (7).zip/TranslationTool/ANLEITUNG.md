
# Detaillierte Anleitung für Visual Studio Code

## Voraussetzungen
- Node.js Version 16 oder höher installiert
- Visual Studio Code installiert
- Terminal/Kommandozeile Grundkenntnisse

## Schritt-für-Schritt Anleitung

### 1. Projekt öffnen
1. Öffnen Sie Visual Studio Code
2. Wählen Sie `File > Open Folder...` (oder Datei > Ordner öffnen...)
3. Navigieren Sie zum Projektordner und wählen Sie ihn aus
4. Der komplette Projektordner sollte nun im VSCode Explorer sichtbar sein

### 2. Terminal öffnen
1. Wählen Sie `Terminal > New Terminal` (oder Terminal > Neues Terminal)
2. Es öffnet sich ein Terminal-Fenster im unteren Bereich von VSCode

### 3. Abhängigkeiten installieren
1. Geben Sie im Terminal ein: `npm install`
2. Warten Sie, bis alle Pakete installiert sind (dies kann einige Minuten dauern)

### 4. Anwendung starten
1. Geben Sie im Terminal ein: `npm run dev`
2. Warten Sie, bis die Meldung "serving on port 3000" erscheint
3. Öffnen Sie Ihren Browser und gehen Sie zu: http://localhost:3000

### 5. Diagnose durchführen
Wenn Sie einen weißen Bildschirm sehen oder die Anwendung nicht wie erwartet funktioniert:

1. Prüfen Sie, ob der Server läuft (Terminal sollte "serving on port 3000" zeigen)
2. Überprüfen Sie den Browser-Status mit der Diagnose-URL: http://localhost:3000/api/health
3. Wenn Sie eine JSON-Antwort mit `{"status":"ok",...}` sehen, läuft der Server korrekt
4. Überprüfen Sie die Browser-Konsole auf Fehlermeldungen (F12 oder Rechtsklick > Untersuchen > Konsole)

### Häufige Fehler

#### "Cannot find module..."
- Führen Sie `npm install` erneut aus
- Prüfen Sie, ob Node.js korrekt installiert ist mit `node -v`

#### "Address already in use"
- Ein anderer Prozess verwendet bereits Port 3000
- Beenden Sie alle anderen Serverprozesse oder ändern Sie den Port in der Konfiguration

#### Weißer Bildschirm ohne Fehlermeldung
- NICHT Live Server verwenden - diese Anwendung benötigt das Express-Backend
- Direkt http://localhost:3000 im Browser öffnen, nicht die HTML-Dateien

## Wichtiger Hinweis
Diese Anwendung ist ein **Full-Stack-Projekt** und funktioniert nicht mit statischen Webserver-Erweiterungen wie Live Server. Das Frontend wird vom Backend (Express) ausgeliefert und kann nicht unabhängig davon ausgeführt werden.
